module.exports = {
  mongoURI: `mongodb+srv://colin:lRakmEf75v6gX9QM@cluster0-lefjp.mongodb.net/test?retryWrites=true`
};