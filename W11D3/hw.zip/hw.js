
Array.prototype.titleize = function() {

  
}