

let callback = function(time) {
  console.log(`${time} is Hammertime!`);
};

let hammerTime = function(time) {
  let timeToWait = 5000;
  window.setTimeout(callback(time), timeToWait);
};

hammerTime('now o clock');
